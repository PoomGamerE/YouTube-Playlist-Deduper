# YouTube Playlist Deduper (Chrome Extension)

v1.3.0 — Published-date sort + Recommended-section loader

- **Temporary sort** supports **Published date (newest/oldest)** — ตรงกับ “วันที่เผยแพร่ (ล่าสุด/เก่าสุด)” ในเมนูไทย.
- **Autoload** ยึดหัวข้อ “**วิดีโอที่แนะนำ**” เพื่อกระตุ้นการโหลดต่อ ถ้าไม่เดินจะลงสุดแล้วเด้งกลับมายังหัวข้อนี้.
- AUTO: Sort → Load → Scan → Remove → Restore.
